import { datepickerController } from "@library/Datepicker";
import { selectmenuController } from "@library/Selectmenu";

import Co from "@pages/co";

(function () {
  let breakpoint = null;

  function bind() {
    window.addEventListener("scroll", scrollHandler);
    window.addEventListener("resize", resizeHandler);

    breakpoint = window.matchMedia("(min-width:768px)");
    breakpoint.addEventListener("change", breakpointChecker);
  }

  function contentReady() {
    console.log("ready");

    selectmenuController.init(".select-wrap > select");
    datepickerController.init(".datepickerInner");

    bind();

    Co?.init();

    resizeHandler();
    scrollHandler();
    breakpointChecker(breakpoint);
  }

  function scrollHandler() {
    console.log("scroll !!!");
  }

  function resizeHandler() {
    console.log("resize !!!");

    Co?.resize();
  }

  function breakpointChecker(e) {
    if (!e.matches) {
      console.log("breakpoint mobile !!!");
    } else {
      console.log("breakpoint pc !!!");
    }

    Co?.breakpointChecker(e);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", contentReady);
  } else {
    contentReady();
  }

  document.addEventListener("DOMContentLoaded", contentReady);
})();
